/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.Serializable;

/**
 *
 * @author uesr
 */
public class Data  implements Serializable {
    
     public String info;
     
     public Data(String information){
         info=information;
     }
    
}
